<?php

namespace App\Http\super;

use App\Http\super\Auth\SharedData;
use Ions\Foundation\BaseController;
use Ions\Support\Request;
use Ions\Support\Route;
use Throwable;

#[Route('/super')]
class Index extends BaseController
{
    protected string $viewSpace = '@super/';
    protected string $localeFolder = 'super';

    public function _loadedState(Request $request): void
    {
        SharedData::shared($this->twig);
    }

    #[Route('/index')]
    public function index(Request $request): void
    {
        try {
            $this->twig->display($this->viewSpace . 'index.html.twig');
        }catch (Throwable $e) {
            abort(404, $e->getMessage());
        }
    }

}
