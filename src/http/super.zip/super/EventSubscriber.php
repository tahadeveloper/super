<?php

namespace App\Http\super;

use Ions\Foundation\Kernel;
use Ions\Support\Request;
use Ions\Support\Route;

#[Route('/super')]
class EventSubscriber
{
    #[Route('/locale-subscribe', methods: 'post')]
    public function localeSubscribe(Request $request): void
    {
        $locale = $request->get('_locale', config('app.localization.locale'));
        $super = Kernel::session()->get('_super');
        $super['_locale'] = $locale;
        Kernel::session()->set('_super', $super);

        echo $locale;
    }

    #[Route('/theme-style-subscribe', methods: 'post')]
    public function themeStyleSubscribe(Request $request): void
    {
        $themeStyle = $request->get('_theme_style', config('super.theme_style'));
        $super = Kernel::session()->get('_super');
        $super['_theme_style'] = $themeStyle;
        Kernel::session()->set('_super', $super);
    }
}