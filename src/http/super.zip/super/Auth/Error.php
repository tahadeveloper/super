<?php

namespace App\Http\super\Auth;


use Ions\Foundation\BaseController;
use Ions\Support\Request;
use Ions\Support\Route;

#[Route('/super')]
class Error extends BaseController
{
    protected string $viewSpace = '@super/';
    protected string $locale_folder = 'super';

    public function _loadedState(Request $request): void
    {
        SharedData::shared($this->twig);
    }

    #[Route('/error/{method}', requirements: ['method' => 'index'], defaults: ['method' => 'index'])]
    public function index(): void
    {
        $this->twig->display($this->viewSpace . '_Auth/error/error-500.twig');
    }

    #[Route('/error/deny/{id}')]
    public function deny(Request $request): void
    {
        $id = $request->get('id');

        $this->twig->display($this->viewSpace . '_Auth/error/error-500.twig', ['deny_no' => $id]);
    }
}
