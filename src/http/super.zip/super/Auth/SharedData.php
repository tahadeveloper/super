<?php

namespace App\Http\super\Auth;

use Illuminate\Support\Str;
use Ions\Auth\Guard\GuardControl;
use Ions\Auth\Guard\Guard;
use Ions\Auth\Guard\GuardRole;
use Ions\Bundles\Logs;
use Ions\Bundles\Redirect;
use Ions\Foundation\Kernel;
use Ions\Support\Arr;
use Ions\Support\JsonResponse;
use JetBrains\PhpStorm\Pure;
use Naucon\Breadcrumbs\Breadcrumbs;

class SharedData
{
    /**
     * @param $template
     * @param array $options
     * @return object
     */
    public static function shared($template, array $options = []): object
    {
        if (!Guard::check()) {
            Redirect::internal('super/logout');
        }

        $userSession = Kernel::session();

        if ($userSession->has('_super') && isset($userSession->get('_super')['_theme_style'])) {
            config()?->set('super.theme_style', $userSession->get('_super')['_theme_style']);
        }

        $controlSlug = $options['slug'] ?? (Kernel::request()->segment(2) ?? 'index');

        $currentLanguage = appGetLocale();
        $loginUser = Guard::check();
        $roleInfo = GuardRole::single($loginUser->roles[0]->id, $currentLanguage);
        $shared = [
            'login_user' => $loginUser,
            'login_role' => $roleInfo,
            'full_access_permission' => $loginUser->hasAccess('full_control'),
            'side_menu' => GuardRole::hierarchy($loginUser->roles[0]->id, $currentLanguage)
        ];
        $template->addGlobal('share_vars', $shared);

        $controlData = GuardControl::singleBySlug($controlSlug, $currentLanguage);
        if ($controlData) {
            $template->addGlobal('control_slug', $controlData->slug);
            $template->addGlobal('control_name', $controlData->language->name);
            $template->addGlobal('control_actives', $controlData->actives);
        }

        self::breadCrumbs($controlData, $template);

        if ($userSession->has('request_bag')) {
            $template->addGlobal('request_bag', (new JsonResponse($userSession->get('request_bag')))->getContent());
            $userSession->remove('request_bag');
        }

        $forwardErrors = Kernel::session()->flash('forward_errors');
        if ($forwardErrors) {
            $template->addGlobal('forward_errors', $forwardErrors);
        }

        return $loginUser;
    }

    /**
     * @param array $specialRules
     * @return object|null
     */
    public static function inheritAccess(array $specialRules): null|object
    {
        $controlName = Kernel::request()->attributes->get('_controller_name');
        $actionName = Kernel::request()->attributes->get('_method_name');

        $actionName = self::getActionName($specialRules, $actionName);

        $user = Guard::check();
        if ($user->hasAccess('full_control') && !config('app.app_debug')) {
            Logs::create('super.log')
                ->info(
                    'User(' . $user->first_name . ') have full access',
                    ['control' => $controlName, 'action' => $actionName]
                );
        }

        $control = GuardControl::singleBySlug(Str::lower(Str::snake($controlName, '-')));
        $controlActions = GuardControl::actions($control?->id);

        if (!$user->hasAccess('full_control')) {
            if (!$control) {
                echo (new JsonResponse(['status' => false, 'message' => 'Access deny']))->getContent();
                Redirect::internal('super/error/deny/1');
            }

            if (!$action = GuardControl::actionBySlug($actionName, $control->id)) {
                echo (new JsonResponse(['status' => false, 'message' => 'Access deny']))->getContent();
                Redirect::internal('super/error/deny/2');
            }

            if (!$user->hasAccess($control->id . '.' . $action->id)) {
                echo (new JsonResponse(['status' => false, 'message' => 'Access deny']))->getContent();
                Redirect::internal('super/error/deny/3');
            }

            $permissions = $user->getPermissionsInstance()->getSecondaryPermissions();

            // check if control action id in permissions add display true to action
            return $controlActions?->filter(function ($item) use ($control, $permissions) {
                $index = $control->id . '.' . $item->id;
                return $permissions[0][$index] ?? false;
            });
        }

        return $controlActions;
    }

    /**
     * @param mixed $controlData
     * @param $template
     * @return void
     */
    public static function breadCrumbs(mixed $controlData, $template): void
    {
        $breadcrumbs = new Breadcrumbs();
        $segments = Kernel::request()->segments();

        $breadcrumbs->add(trans('titles.dashboard'), appUrl('/super/index'));
        $link = '';
        for ($i = 2, $iMax = count($segments); $i <= $iMax; $i++) {
            $linkName = Kernel::request()->segment($i);
            if (is_numeric($linkName)) {
                continue;
            }
            if (isset($controlData->slug) && Kernel::request()->segment($i) === $controlData->slug) {
                $linkName = 'show';
            }

            if ($i < $iMax & $i > 0) {
                $link .= "/super/" . Kernel::request()->segment($i);
                if ($linkName === 'edit' || $linkName === 'view') {
                    $breadcrumbs->add(trans('titles.' . $linkName));
                } else {
                    $breadcrumbs->add(trans('titles.' . $linkName), appUrl($link));
                }

            } else {
                $breadcrumbs->add(trans('titles.' . $linkName));
            }
        }

        $template->addGlobal('breadcrumbs', $breadcrumbs);
    }

    /**
     * @param array $specialRules
     * @param mixed $actionName
     * @return mixed|string
     */
    #[Pure] private static function getActionName(array $specialRules, mixed $actionName): mixed
    {
        foreach ($specialRules as $ruleKey => $specialRule) {
            if (Arr::accessible($specialRule)) {
                if (in_array($actionName, $specialRule, true)) {
                    $actionName = (string)$ruleKey;
                }
            } elseif ($actionName === $specialRule) {
                $actionName = (string)$ruleKey;
            }
        }
        return $actionName;
    }

}