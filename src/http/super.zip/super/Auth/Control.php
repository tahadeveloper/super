<?php

namespace App\Http\super\Auth;

use Ions\Auth\Guard\GuardControl;
use Ions\Bundles\Redirect;
use Ions\Foundation\BaseController;
use Ions\Support\Arr;
use Ions\Support\Request;
use Ions\Support\Route;
use JetBrains\PhpStorm\NoReturn;
use JetBrains\PhpStorm\Pure;
use Throwable;

#[Route('/super')]
class Control extends BaseController
{
    protected string $viewSpace = '@super/';
    protected string $localeFolder = 'super';

    public function _loadedState(Request $request): void
    {
        SharedData::shared($this->twig);
        $this->locale = appGetLocale();
        SharedData::inheritAccess([
            'add' => 'save',
            'edit' => 'update',
            'index' => 'sortItems',
            'destroy' => 'deleteAction'
        ]);
    }

    #[Pure] private function rules($type, $id = null): array
    {
        $rules = [
            'slug' => 'required|unique:controls,slug,' . $id,
            'name_ar' => 'required',
            'name_en' => 'required',
            'status' => 'required',
            'link' => 'required',
            'active_name' => 'required',
            'id' => 'required|numeric|not_in:0|exists:controls,id',
            'action_id' => 'required|numeric|not_in:0|exists:actions,id',
        ];
        return match ($type) {
            'store' => Arr::only($rules, ['slug', 'name_ar', 'name_en', 'status']),
            'update' => Arr::only($rules, ['slug', 'name_ar', 'name_en', 'status', 'id']),
            'single', 'delete' => Arr::only($rules, ['id']),
            'deleteAction' => Arr::only($rules, ['action_id']),
            default => $rules,
        };
    }

    #[Route('/control/{method}', requirements: ['method' => 'index'], defaults: ['method' => 'index'])]
    public function index(): void
    {
        $controls = GuardControl::hierarchy($this->locale);
        $this->twig->display($this->viewSpace . '_Auth/control/show.html.twig', ['controls' => $controls]);
    }

    #[Route('/control/sortItems', methods: 'post')]
    public function sortItems(Request $request): void
    {
        $orderJson = $request->get('orderJson');

        try {
            GuardControl::order($orderJson);
            echo true;
        } catch (Throwable) {
            echo false;
        }
    }

    #[Route('/control/add')]
    public function add(Request $request): void
    {
        $parents = GuardControl::all($this->locale);
        $this->twig->display($this->viewSpace . '_Auth/control/add.html.twig',
            $request->get('forwards', []) + $request->all() + ['parents' => $parents]
        );
    }

    #[Route('/control/save', methods: 'post')]
    public function save(Request $request): void
    {
        if (!csrfCheck('control_add')) {
            Redirect::internal('super/control/add');
        }

        if (!empty($result = validate($request->all(), $this->rules('store')))) {
            $request->attributes->set('forwards', ['error_message' => $result]);
            $this->add($request);
            exit();
        }

        $params = [
            'slug' => $request->get('slug'),
            'parent_id' => $request->get('parent_id'),
            'status' => $request->get('status'),
            'icon' => $request->get('icon'),
            'link' => $request->get('link'),
            'active_name' => $request->get('active_name'),
            'is_tag' => $request->get('is_tag'),
            'languages' => [
                ['language_name' => 'ar', 'name' => $request->get('name_ar')],
                ['language_name' => 'en', 'name' => $request->get('name_en')],
            ],
            'actions' => []
        ];

        foreach ($request->get('actions_container', []) as $action) {
            $params['actions'][] = [
                'slug' => $action['action_slug'],
                'status' => $action['action_status'],
                'languages' => [
                    ['language_name' => 'ar', 'action_name' => $action['action_name_ar']],
                    ['language_name' => 'en', 'action_name' => $action['action_name_en']],
                ]
            ];
        }
        try {

            GuardControl::add(toObject($params));

            $this->session->set('request_bag', ['status' => 'success', 'message' => trans('messages_box.inside_msg.success_message')]);
            Redirect::internal('super/control');
        } catch (Throwable $e) {
            $request->attributes->set('forwards',
                ['error_message' => trans('messages_box.inside_msg.error.fail') . $e->getMessage()]);
            $this->add($request);
        }
    }

    #[Route('/control/edit/{id}')]
    public function edit(Request $request): void
    {
        if (!empty(validate(['id' => $request->get('id')], $this->rules('single')))) {
            Redirect::internal('super/control');
        }

        $id = $request->get('id');
        $parents = GuardControl::all($this->locale, $id);
        $control = GuardControl::single($id);
        $this->twig->display($this->viewSpace . '_Auth/control/edit.html.twig',
            $request->get('forwards', []) + ['control' => $control, 'parents' => $parents]
        );
    }

    #[Route('/control/update', methods: 'post')]
    public function update(Request $request): void
    {
        $id = $request->get('id');

        if (!csrfCheck('control_edit')) {
            Redirect::internal('super/control/edit/' . $id);
        }

        if (!empty($result = validate($request->all(), $this->rules('update', $id)))) {
            $request->attributes->set('forwards', ['error_message' => $result]);
            $this->edit($request);
            exit();
        }

        $params = [
            'id' => $request->get('id'),
            'slug' => $request->get('slug'),
            'parent_id' => $request->get('parent_id'),
            'status' => $request->get('status'),
            'icon' => $request->get('icon'),
            'link' => $request->get('link'),
            'active_name' => $request->get('active_name'),
            'is_tag' => $request->get('is_tag'),
            'languages' => [
                ['language_id' => $request->get('name_ar_id'), 'language_name' => 'ar', 'name' => $request->get('name_ar')],
                ['language_id' => $request->get('name_en_id'), 'language_name' => 'en', 'name' => $request->get('name_en')],
            ],
            'actions' => []
        ];

        foreach ($request->get('actions_container', []) as $action) {
            $params['actions'][] = [
                'action_id' => $action['action_id'],
                'slug' => $action['action_slug'],
                'status' => $action['action_status'],
                'languages' => [
                    ['action_language_id' => $action['action_id_ar'], 'language_name' => 'ar', 'action_name' => $action['action_name_ar']],
                    ['action_language_id' => $action['action_id_en'], 'language_name' => 'en', 'action_name' => $action['action_name_en']],
                ]
            ];
        }
        try {
            GuardControl::update(toObject($params));
            $this->session->set('request_bag', ['status' => 'success', 'message' => trans('messages_box.inside_msg.success_edit_message')]);

            Redirect::internal('super/control');
        } catch (Throwable $e) {
            $request->attributes->set('forwards',
                ['error_message' => trans('messages_box.inside_msg.error.fail') . $e->getMessage()]);
            $this->edit($request);
        }
    }

    #[NoReturn] #[Route('/control/delete')]
    public function destroy(Request $request): void
    {
        if (!csrfCheck('control_show')) {
            display(toJson(['status' => false, 'message' => trans('messages_box.csrf_message')]));
        }

        if (!empty($result = validate(['id' => $request->get('id')], $this->rules('delete')))) {
            display(toJson(['status' => false, 'message' => $result]));
        }

        $id = $request->get('id');
        if (!GuardControl::delete($id)) {
            display(toJson(['status' => false, 'message' => trans('messages_box.delete_error')]));
        }
        display(toJson(['status' => true, 'message' => '']));
    }

    #[NoReturn] #[Route('/control/deleteAction')]
    public function deleteAction(Request $request): void
    {
        if (!empty($result = validate(['action_id' => $request->get('action_id')], $this->rules('deleteAction')))) {
            display(toJson(['status' => false, 'message' => $result]));
        }

        $id = $request->get('action_id');
        if (!GuardControl::deleteAction($id)) {
           display(toJson(['status' => false, 'message' => $id]));
        }

        display(toJson(['status' => true, 'message' => '']));
    }
}
