"use strict";var KTAppsSocialFeeds={init:function(){}};KTUtil.onDOMContentLoaded((function(){KTAppsSocialFeeds.init()}));
//# sourceMappingURL=feeds.js.map
