"use strict";var KTGeneralImageInputDemos={init:function(){}};KTUtil.onDOMContentLoaded((function(){KTGeneralImageInputDemos.init()}));
//# sourceMappingURL=image-input.js.map
