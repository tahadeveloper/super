"use strict";var KTGeneralDrawerDemos={init:function(){}};KTUtil.onDOMContentLoaded((function(){KTGeneralDrawerDemos.init()}));
//# sourceMappingURL=drawer.js.map
