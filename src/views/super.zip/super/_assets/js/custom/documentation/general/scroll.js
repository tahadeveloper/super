"use strict";var KTGeneralScrollDemos={init:function(){}};KTUtil.onDOMContentLoaded((function(){KTGeneralScrollDemos.init()}));
//# sourceMappingURL=scroll.js.map
